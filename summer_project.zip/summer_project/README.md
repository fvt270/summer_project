# Rasmus Willsleff Andersen summer project 2024
### Code made with python 3.11.9