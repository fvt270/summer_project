conda activate base
/groups/sbinlab/software/PRISM_tools/rosetta_stability-v0.2.6/software/rosetta_ddG_pipeline/ -s ./drugs/SQV/2nmw.pdb -o ./drugs/SQV/run/ -i create
