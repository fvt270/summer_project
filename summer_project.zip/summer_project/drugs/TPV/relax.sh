conda activate base
/groups/sbinlab/software/PRISM_tools/rosetta_stability-v0.2.6/software/rosetta_ddG_pipeline/ -s ./drugs/TPV/1d4y.pdb -o ./drugs/TPV/run/ -i create
